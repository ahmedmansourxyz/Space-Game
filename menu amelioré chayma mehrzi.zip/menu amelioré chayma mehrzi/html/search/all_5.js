var searchData=
[
  ['setting_7',['setting',['../menu_8c.html#aae0bb3d9dbc5f5dabbd7794a164da90b',1,'menu.c']]],
  ['sounds_8',['sounds',['../menu_8c.html#aee2141a7bd044609084583574361b53f',1,'menu.c']]]
];
