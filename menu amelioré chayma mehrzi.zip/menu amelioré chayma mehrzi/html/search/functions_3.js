var searchData=
[
  ['resolution_15',['resolution',['../menu_8c.html#a6d61305ca60a59961798288324b30b56',1,'menu.c']]]
];
