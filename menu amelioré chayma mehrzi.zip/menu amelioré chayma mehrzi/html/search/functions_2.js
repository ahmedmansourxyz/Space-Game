var searchData=
[
  ['quitt_14',['quitt',['../menu_8c.html#acb5fffb294c1fae264033b22c8ca5a89',1,'menu.c']]]
];
