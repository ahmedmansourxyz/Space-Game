var searchData=
[
  ['choose_0',['choose',['../menu_8c.html#a426a899f0a709972d336a5d1f593630b',1,'menu.c']]],
  ['controls_1',['controls',['../menu_8c.html#afaa894f33d1ea4952cc83fa13e23352f',1,'menu.c']]]
];
