var searchData=
[
  ['sauvegarde_9',['sauvegarde',['../menu_8c.html#a9e6e7efabff95c8dcd835ff9e58b3f39',1,'menu.c']]],
  ['save_2ec_10',['save.c',['../save_8c.html',1,'']]],
  ['savegame_11',['savegame',['../save_8c.html#afce1e5291c0fc4eb22d45ae7ffe3ab6a',1,'save.c']]],
  ['setting_12',['setting',['../menu_8c.html#aae0bb3d9dbc5f5dabbd7794a164da90b',1,'menu.c']]],
  ['sounds_13',['sounds',['../menu_8c.html#aee2141a7bd044609084583574361b53f',1,'menu.c']]]
];
