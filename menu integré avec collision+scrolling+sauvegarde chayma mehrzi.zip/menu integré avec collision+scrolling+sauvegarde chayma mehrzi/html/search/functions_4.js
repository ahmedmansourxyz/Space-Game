var searchData=
[
  ['resetgame_22',['resetgame',['../save_8c.html#a693bf8138515808a78fd3edfd088bb55',1,'save.c']]],
  ['resolution_23',['resolution',['../menu_8c.html#a6d61305ca60a59961798288324b30b56',1,'menu.c']]]
];
