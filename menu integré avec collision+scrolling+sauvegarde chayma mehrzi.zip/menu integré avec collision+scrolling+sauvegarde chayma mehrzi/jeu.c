#include "jeu.h"
#include "save.h"
/*
* @file [jeu.c].
* @author : Rangers
* @brief : fonction du boucle de jeu 
* @date : 2020/11/09
* @version 1
*/
SDL_Color GetPixel(SDL_Surface *background_mask,int x,int y)
{
SDL_Color color;
Uint32 col=0;


char* pPosition=(char* ) background_mask->pixels;





pPosition+= (background_mask->pitch * y);


pPosition+= (background_mask->format->BytesPerPixel *x);


memcpy(&col ,pPosition ,background_mask->format->BytesPerPixel);


SDL_GetRGB(col,background_mask->format, &color.r, &color.g, &color.b);
return (color);
}
/**
* @brief to detect collision .
* @param backgroundmask image de collision du background
* @param positionplayer position du joueur 
* @return entier 1 si collision , sinon 0 
*/
int detectCollPP (SDL_Surface * backgroundmask, SDL_Rect positionplayer){




  SDL_Color colobs;

  SDL_Color colgotten;

  SDL_Rect Pos[8];

int collision = 0, i = 0;
colobs.r=0;
colobs.g=0;
colobs.b=0;


  Pos[0].x = positionplayer.x;

  Pos[0].y =positionplayer.y;

  Pos[1].x = positionplayer.x + (positionplayer.w /2);

  Pos[1].y = positionplayer.y;

  Pos[2].x = positionplayer.x + positionplayer.w;

  Pos[2].y = positionplayer.y;

  Pos[3].x = positionplayer.x;

  Pos[3].y =  positionplayer.y + (positionplayer.h/2);

  Pos[4].x = positionplayer.x;

  Pos[4].y = positionplayer.y + positionplayer.h;

  Pos[5].x = positionplayer.x + (positionplayer.w /2);

  Pos[5].y =  positionplayer.y + positionplayer.h;

  Pos[6].x = positionplayer.x + positionplayer.w;

  Pos[6].y = positionplayer.y + positionplayer.h;

  Pos[7].x = positionplayer.x + positionplayer.w;

  Pos[7].y = positionplayer.y + (positionplayer.h/2);


while ((i<=7) && (collision == 0)) {
colgotten = GetPixel (backgroundmask, Pos[i].x, Pos[i].y);



    if ((colobs.r == colgotten.r) &&  (colobs.b == colgotten.b) &&

  (colobs.g == colgotten.g)){

       collision = 1;

    }else{

      i++;

    }

}

return collision;
}
/**
* @brief to intialiser la boucle du jeu .
* @param ecran 
* @return nothing
*/
void jouer(SDL_Surface* ecran,Mix_Chunk *son,Mix_Music *musique)
{
SDL_Surface *background1=NULL,*player=NULL,*backgroundmask;
SDL_Rect positionbackground1,positionplayer,positionmilieu,positionbackgroundmask;
SDL_Event event;
int continuer = 1;
background1=IMG_Load("background1.png");
    positionbackground1.x = 0;
    positionbackground1.y = 0;
player=IMG_Load("player1.png");
    positionplayer.x =1366/2;
    positionplayer.y =350;
    positionplayer.w=96;
    positionplayer.h=175;
    positionmilieu.x = 1366/2;
    positionmilieu.y = 678/2;

backgroundmask=IMG_Load("backgroundmask.png");

   positionbackgroundmask.x=0;
   positionbackgroundmask.y=0;

	loadgame(&positionplayer);
 

SDL_EnableKeyRepeat(10,10) ; 


    while (continuer) 
    {
            SDL_WaitEvent(&event);
            switch(event.type)
        {
            case SDL_QUIT:
                continuer = 0;
                break;
               case SDL_KEYDOWN:
             {
                switch(event.key.keysym.sym)
                {
			      case SDLK_ESCAPE : 
			      {
			      SDL_EnableKeyRepeat(0,0) ; 
			      sauvegarde(ecran,son,musique, positionplayer);
			      }
			      break ; 
			      case SDLK_LEFT : 
			      	if(positionplayer.x>700)positionplayer.x-=10 ; 
			      	if (detectCollPP(backgroundmask,positionplayer))
			      	
			      	     positionplayer.x+=10;
			      break ; 
			      case SDLK_RIGHT: 
			      if(positionplayer.x<3700)positionplayer.x+=10 ;
			      
	                      if (detectCollPP(backgroundmask,positionplayer)) 
	                      positionplayer.x-=10;
			      
			      break ; 
			      case SDLK_UP : 
			      if(positionplayer.y>10)positionplayer.y-=10 ; 
			       if (detectCollPP(backgroundmask,positionplayer)) 
			       positionplayer.y+=10;
			      break;
			      case SDLK_DOWN :
			      if(positionplayer.y<600)positionplayer.y+=10 ;
			      if (detectCollPP(backgroundmask,positionplayer)) 
			        positionplayer.y-=10;
			      break;  
			      }
			      break;
			      }
			      }
			      
			      positionbackground1.x = -positionplayer.x+(1366/2);
			      positionmilieu.y = positionplayer.y;
SDL_BlitSurface ( background1,  NULL ,  ecran , &positionbackground1);

SDL_BlitSurface ( player,   NULL , ecran , &positionmilieu);
	SDL_Flip(ecran) ;
       SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 0, 0, 0));
       SDL_Delay(50);
	} 
    SDL_FreeSurface(background1);
    SDL_FreeSurface(player);
        SDL_FreeSurface(backgroundmask);
       SDL_Quit();
       }
