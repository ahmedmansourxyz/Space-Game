var searchData=
[
  ['initialisation_5fbox_23',['initialisation_box',['../fc_8c.html#a2d6ea22b4144ae5204202b8be18853b6',1,'fc.c']]],
  ['initialisation_5fperso_24',['initialisation_perso',['../fc_8c.html#a3c2476adaa94fb3e356e521ae535a881',1,'fc.c']]],
  ['intialisation_5fenemy_25',['intialisation_enemy',['../fc_8c.html#a047a7ebb5783a72e5f3c8cf1b795d1fc',1,'fc.c']]]
];
