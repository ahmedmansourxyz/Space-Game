var searchData=
[
  ['box_1',['box',['../structbox.html',1,'box'],['../structboxx.html#a93209334e79ad99a2c8fb88984d919e2',1,'boxx::box()']]],
  ['boxx_2',['boxx',['../structboxx.html',1,'']]]
];
