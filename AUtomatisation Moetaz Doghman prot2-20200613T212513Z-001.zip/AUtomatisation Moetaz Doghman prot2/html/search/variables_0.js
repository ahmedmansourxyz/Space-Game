var searchData=
[
  ['box_27',['box',['../structboxx.html#a93209334e79ad99a2c8fb88984d919e2',1,'boxx']]]
];
