var searchData=
[
  ['play_5',['play',['../menu_8c.html#a952c1531b80081163b2f58db255e85c3',1,'menu.c']]]
];
