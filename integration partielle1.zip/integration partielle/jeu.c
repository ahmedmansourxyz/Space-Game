#include "jeu.h"
#include "save.h"
/*
* @file [jeu.c].
* @author : Rangers
* @brief : fonction du boucle de jeu 
* @date : 2020/11/09
* @version 1
*/
SDL_Color GetPixel(SDL_Surface *background_mask,int x,int y)
{
SDL_Color color;
Uint32 col=0;


char* pPosition=(char* ) background_mask->pixels;





pPosition+= (background_mask->pitch * y);


pPosition+= (background_mask->format->BytesPerPixel *x);


memcpy(&col ,pPosition ,background_mask->format->BytesPerPixel);


SDL_GetRGB(col,background_mask->format, &color.r, &color.g, &color.b);
return (color);
}
/**
* @brief to detect collision .
* @param backgroundmask image de collision du background
* @param positionplayer position du joueur 
* @return entier 1 si collision , sinon 0 
*/
int detectCollPP (SDL_Surface * backgroundmask, SDL_Rect positionplayer){




  SDL_Color colobs;

  SDL_Color colgotten;

  SDL_Rect Pos[8];

int collision = 0, i = 0;
colobs.r=0;
colobs.g=0;
colobs.b=0;


  Pos[0].x = positionplayer.x;

  Pos[0].y =positionplayer.y;

  Pos[1].x = positionplayer.x + (positionplayer.w /2);

  Pos[1].y = positionplayer.y;

  Pos[2].x = positionplayer.x + positionplayer.w;

  Pos[2].y = positionplayer.y;

  Pos[3].x = positionplayer.x;

  Pos[3].y =  positionplayer.y + (positionplayer.h/2);

  Pos[4].x = positionplayer.x;

  Pos[4].y = positionplayer.y + positionplayer.h;

  Pos[5].x = positionplayer.x + (positionplayer.w /2);

  Pos[5].y =  positionplayer.y + positionplayer.h;

  Pos[6].x = positionplayer.x + positionplayer.w;

  Pos[6].y = positionplayer.y + positionplayer.h;

  Pos[7].x = positionplayer.x + positionplayer.w;

  Pos[7].y = positionplayer.y + (positionplayer.h/2);


while ((i<=7) && (collision == 0)) {
colgotten = GetPixel (backgroundmask, Pos[i].x, Pos[i].y);



    if ((colobs.r == colgotten.r) &&  (colobs.b == colgotten.b) &&

  (colobs.g == colgotten.g)){

       collision = 1;

    }else{

      i++;

    }

}

return collision;
}






SDL_Surface* numberPics[10];


void displayNumber(int num, SDL_Surface* ecran, SDL_Rect pos)
{
	int nums[6] = {0,0,0,0,0,0};
	int cid = 5;
	while(num>0)
	{
		nums[cid--] = num%10;
		num = num/10;
	}
	
	SDL_Rect cpos;
	cpos.x = pos.x;
	cpos.y = pos.y;
	
	for(int o=0; o<6; o++)
	{
		SDL_BlitSurface(numberPics[nums[o]], NULL, ecran, &cpos);
		cpos.x = cpos.x + 150;
	}
	
}







/**
* @brief to intialiser la boucle du jeu .
* @param ecran 
* @return nothing
*/
void jouer(SDL_Surface* ecran,Mix_Chunk *son,Mix_Music *musique)
{
SDL_Surface *background1=NULL,*player=NULL,*backgroundmask,*enemy,*vie1,*vie2,*vie3,*gameover,*minimap,*miniperso; 
SDL_Rect positionbackground1,positionplayer,positionmilieu,positionbackgroundmask,positionenemy, positionenemy1, positionscore,positionvie,positiongameover,positionminimap,positionminiperso;
SDL_Event event;
int continuer = 1;
int enemydir = 1;
vie1=IMG_Load("coeur1.png");
vie2=IMG_Load("coeur2.png");
vie3=IMG_Load("coeur3.png");
background1=IMG_Load("background1.png");
    positionbackground1.x = 0;
    positionbackground1.y = 0;
player=IMG_Load("player1.png");
    positionplayer.x =1366/2;
    positionplayer.y =350;
    positionplayer.w=96;
    positionplayer.h=175;
    positionmilieu.x = 1366/2;
    positionmilieu.y = 678/2;
    int jumpVel = 0;
enemy=IMG_Load("enemy.png");
    positionenemy.x=1100;
    positionenemy.y=550;
gameover=IMG_Load("gameover.png");
    positiongameover.x=0;
    positiongameover.y=0;
    positionvie.x = 1366-210;
    positionvie.y = 10;
    
    	positionminiperso.x=900;
	positionminiperso.y=90;
	positionminimap.x=900;
	positionminimap.y=85;
	minimap = IMG_Load("minimap.png");
	miniperso = IMG_Load("miniperso.png");

    int vie=3;
    int score = 0;
    
    int cnid = 0;
    numberPics[cnid++] = IMG_Load("0.png");
    numberPics[cnid++] = IMG_Load("1.png");
    numberPics[cnid++] = IMG_Load("2.png");
    numberPics[cnid++] = IMG_Load("3.png");
    numberPics[cnid++] = IMG_Load("4.png");
    numberPics[cnid++] = IMG_Load("5.png");
    numberPics[cnid++] = IMG_Load("6.png");
    numberPics[cnid++] = IMG_Load("7.png");
    numberPics[cnid++] = IMG_Load("8.png");
    numberPics[cnid++] = IMG_Load("9.png");
    
    

backgroundmask=IMG_Load("backgroundmask.png");

   positionbackgroundmask.x=0;
   positionbackgroundmask.y=0;


	positionscore.x = 0;
	positionscore.y = 0;
    

	loadgame(&positionplayer, &score,&vie);
 

SDL_EnableKeyRepeat(10,10) ; 


    while (continuer) 
    {
            while(SDL_PollEvent(&event))
            switch(event.type)
        {
            case SDL_QUIT:
                continuer = 0;
                break;
               case SDL_KEYDOWN:
             {
                switch(event.key.keysym.sym)
                {
			      case SDLK_ESCAPE : 
			      {
			      SDL_EnableKeyRepeat(0,0) ; 
			      sauvegarde(ecran,son,musique, positionplayer, score,vie);
			      }
			      break ; 
			      case SDLK_LEFT : 
			      	if(positionplayer.x>700)positionplayer.x-=10 ; 
			      	if (detectCollPP(backgroundmask,positionplayer))
			      	
			      	     positionplayer.x+=10; 
			      	     positionminiperso.x-=1; 

			      break ; 
			      case SDLK_RIGHT: 
			      if(positionplayer.x<3700)positionplayer.x+=10 ;
			      
	                      if (detectCollPP(backgroundmask,positionplayer)) 
	                      positionplayer.x-=10;
	                      positionminiperso.x+=1;

			      
			      break ; 
			      case SDLK_UP :
			      	jumpVel = -20;
			      break;
			      case SDLK_DOWN :
			      if(positionplayer.y<600)positionplayer.y+=10 ;
			      if (detectCollPP(backgroundmask,positionplayer)) 
			        positionplayer.y-=10;




			        break;  
			      }
			      break;
			      }
			      }
			      
			      
	jumpVel = jumpVel+1;
	
	int dir = jumpVel>0?1:-1;
	
	int absvel = jumpVel<0?-jumpVel:jumpVel;
	for(int i=0; i<absvel; i++)
	{
		positionplayer.y+=dir;
		if(detectCollPP(backgroundmask,positionplayer) || positionplayer.y<10)
		{
			jumpVel=0;
			positionplayer.y-=dir;
			printf("stopping\n");
			break;
		}
	}
			      
			      int diff = positionenemy.x-(1200);
			      if(diff<0)diff*=-1;
			      
			      if(diff>120)
			      {
			      	enemydir*=-1;

			      }
			      positionenemy.x+=enemydir*10;
			      
			      positionbackground1.x = -positionplayer.x+(1366/2);
			      positionmilieu.y = positionplayer.y;
			      positionenemy1.x=positionenemy.x-positionplayer.x+1366/2;
			      positionenemy1.y=positionenemy.y;
			      
			       
			    int xdiff = positionenemy.x+75-positionplayer.x-positionplayer.w/2;
			    int ydiff = positionenemy.y+80-positionplayer.y-positionplayer.h;
			    int dist = xdiff*xdiff+ydiff*ydiff;
			    printf("dist = %d %d\n", positionplayer.x, positionenemy.x);
			    if(dist <=80*80)
			    {
			    	vie--;
			    	positionplayer.x =1366/2;
				positionplayer.y =350;
			    	if(vie==0)
			    	{
			    		
			    		resetgame();

			    		SDL_BlitSurface ( gameover,  NULL ,  ecran , &positiongameover);
			    	        SDL_Flip(ecran) ;
			    	        SDL_Delay(2500);
			    	        
			    			
			    		menu(ecran, musique);
			    	}
			    	
			    }
			      

			      
SDL_BlitSurface ( background1,  NULL ,  ecran , &positionbackground1);
SDL_BlitSurface ( enemy,  NULL ,  ecran , &positionenemy1);
 SDL_BlitSurface(minimap,NULL, ecran, &positionminimap);
			       SDL_BlitSurface(miniperso,NULL,ecran,&positionminiperso);

score = score+1;
displayNumber(score, ecran, positionscore);
SDL_BlitSurface ( vie==1?vie1:(vie==2?vie2:vie3),  NULL ,  ecran , &positionvie);

SDL_BlitSurface ( player,   NULL , ecran , &positionmilieu);
	SDL_Flip(ecran) ;
       SDL_FillRect(ecran, NULL, SDL_MapRGB(ecran->format, 0, 0, 0));
       SDL_Delay(50);
	} 
    SDL_FreeSurface(background1);
    SDL_FreeSurface(player);
    SDL_FreeSurface(enemy);
        SDL_FreeSurface(miniperso);
            SDL_FreeSurface(minimap);
        SDL_FreeSurface(backgroundmask);
       SDL_Quit();
       }
