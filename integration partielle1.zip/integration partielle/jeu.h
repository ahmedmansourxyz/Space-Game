
#include <stdlib.h>
#include <stdio.h>
#include <SDL/SDL.h>
#include <SDL/SDL_image.h>
#include <SDL/SDL_mixer.h>









void jouer(SDL_Surface* ecran,Mix_Chunk *son,Mix_Music *musique);
